from io import StringIO
import numpy as np
import re
import spotlight
from datetime import date
import spacy
from spacy import displacy
from spacy.matcher import Matcher
from dateutil.parser import parse
import PyPDF2
import os
import glob
import time

nlp = spacy.load('de')

#Creating custom Flag Atrributes for matching rules.
is_au = nlp.vocab.add_flag(lambda text: text in ['Aufl'])
IS_tocStartPunct = nlp.vocab.add_flag(lambda text: text in [',,', '„', '“'])
stop = nlp.vocab.add_flag(lambda text: text in ['.'])
IS_Rn_Nr_Art = nlp.vocab.add_flag(lambda text: text in ['Rn', 'Nr', 'Art'])
IS_BRACK = nlp.vocab.add_flag(lambda text: text in ['(', ')'])
IS_spec_list = nlp.vocab.add_flag(lambda text: text in ['Abs', 'Rn', 'Nr', 'Auf1'])
IS_AL = nlp.vocab.add_flag(lambda text: text in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K'])
rn_art = nlp.vocab.add_flag(lambda text: text in ['Rn', 'Art'])
IS_DASHPUNCT = nlp.vocab.add_flag(lambda text: text in ['-', '_'])
IS_INHALT = nlp.vocab.add_flag(lambda text: text in ['Inhalt', 'Inhaltsübersicht'])
IS_SINGLELETTER = nlp.vocab.add_flag(
    lambda text: text in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
                          'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'])
IS_Nr = nlp.vocab.add_flag(lambda text: text in ['Nr'])
IS_XIV = nlp.vocab.add_flag(lambda text: text in ['X', 'I', 'II', 'III', 'V'])
IS_XV = nlp.vocab.add_flag(lambda text: text in ['X', 'V'])

Numerals = []
RuleList = []
SubRule = ['gesetz1', 'gesetz2', 'gesetz3', 'gesetz4', 'gesetz5']


#Function to convert pdf to text
def extractText(file):
    pdfReader = PyPDF2.PdfFileReader(file)
    num_pages = pdfReader.getNumPages()
    count = 0
    txt = ''
    while count < num_pages:
        pageObj = pdfReader.getPage(count)
        # print(pageObj.extractText())
        count += 1
        txt += pageObj.extractText()
    return txt


#Function to check if the token is a Roman Numeral or not.
def checkIfRomanNumeral(numeral):
    validRomanNumerals = ["M", "D", "C", "L", "X", "V", "I"]
    for letters in numeral:
        if letters not in validRomanNumerals:
            return False
    return True


files = []

#Feed the path of the directory with the PDF files to be treated.
path = 'C:/Users/PagolPoka/Desktop/Docs'

for filename in os.listdir(path):
    files.append(filename)

ticks = time.time()

print("Number of ticks since 12:00am, January 1, 1970:", ticks)

counter = 0
for filename in glob.glob(os.path.join(path, '*.pdf')):
    output = 'Rulefile_' + files[counter] + '.txt'
    print(output)

    startRead = time.time()
    text1 = extractText(filename)

    # print("The Content of the File is: ", text1)
    endRead = time.time()
    hours, rem = divmod(endRead - startRead, 3600)
    minutes, seconds = divmod(rem, 60)
    print("Time taken to read the PDF")
    print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    with open('TimeTrack.txt', 'a') as f:
        print("", file=f)
        print("**********", files[counter], "**********", file=f)
        print("", file=f)
        print(files[counter], file=f)
        print("Time taken to read the PDF", file=f)
        print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds), file=f)

    print("**********************TOKENIZATION***********************************")
    doct = nlp(text1)
    token_list = []
    for toc in doct:
        token_list.append(toc.text)

    endNLP = time.time()
    hours, rem = divmod(endNLP - endRead, 3600)
    minutes, seconds = divmod(rem, 60)
    print("Time taken Spacy's Tokenization and Feature Extraction")
    print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    with open('TimeTrack.txt', 'a') as f:
        print("", file=f)
        print("Time taken Spacy's Tokenization and Feature Extraction", file=f)
        print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds), file=f)

    ########################## Roman Numerals Identifier #########################
    startRoman = time.time()

    for token in doct:
        if checkIfRomanNumeral(token.text):
            Numerals.append(token.text)

    # Convert list to set and then back to list
    Numerals = list(set(Numerals))
    print(Numerals)

    endRoman = time.time()
    hours, rem = divmod(endRoman - startRoman, 3600)
    minutes, seconds = divmod(rem, 60)
    print("Time taken Roman Numeral Extraction")
    print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    with open('TimeTrack.txt', 'a') as f:
        print("", file=f)
        print("Time taken Roman Numeral Extraction", file=f)
        print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds), file=f)

    ########################## PostProcessing #########################
    token_list_d = []
    d = "."
    for line in token_list:
        s = line.split('.')
        if (len(s) == 1):
            token_list_d.append(line)
        else:
            token_list_d.append(s[0])
            token_list_d.append('.')
            token_list_d.append(s[1])
    new_token_list = []
    for toc in token_list_d:
        if (len(toc) == 1):
            new_token_list.append(toc)
        else:
            temp = re.findall('[a-zA-Z\x7f-\xff]+|\\d+', toc)
            for to in temp:
                new_token_list.append(to)

    newN_token_list = []
    for new_toc in new_token_list:
        if new_toc != '\n':
            newN_token_list.append(new_toc)


    newWOdotList = []
    for dtoc in newN_token_list:
        temps = dtoc.split('.')
        if (len(temps) == 1):
            newWOdotList.append(dtoc)
        else:
            newWOdotList.append(temps[0])
            newWOdotList.append('.')
            newWOdotList.append(temps[1])
    newWOspace = []
    for stoc in newWOdotList:
        if stoc != "":
            newWOspace.append(stoc)

    newWOnline = []
    for ntoc in newWOspace:
        if ntoc != "\n":
            newWOnline.append(ntoc)

    str11 = " ".join(new_token_list)
    str14 = " ".join(newN_token_list)
    str12 = " ".join(newWOdotList)
    str13 = " ".join(newWOspace)
    # doc = nlp(str13)
    # doc1 = nlp(str12)
    doc2 = nlp(str14)
    # print(doc2)
    startRuleMatch = time.time()

    # **********************Rule: toc-chapter**********************
    IS_ROMAN = nlp.vocab.add_flag(lambda text: text in Numerals)
    matcher = Matcher(nlp.vocab)

    toc_chapterTop1 = [{'ORTH': "Kapitel"}, {IS_ROMAN: True}, {IS_DASHPUNCT: True, 'OP': '?'},
                       {'LIKE_NUM': False, 'IS_PUNCT': False, IS_SINGLELETTER: False, IS_INHALT: False, 'OP': '+'},
                       {'LIKE_NUM': False, 'IS_PUNCT': False, IS_SINGLELETTER: False, IS_INHALT: False, 'OP': '?'},
                       {'LIKE_NUM': False, 'IS_PUNCT': False, IS_SINGLELETTER: False, IS_INHALT: False, 'OP': '?'},
                       {'LIKE_NUM': False, 'IS_PUNCT': False, IS_SINGLELETTER: False, IS_INHALT: False, 'OP': '?'},
                       {'LIKE_NUM': False, 'IS_PUNCT': False, IS_SINGLELETTER: False, IS_INHALT: False, 'OP': '?'}]
    toc_chapterTop2 = [{'ORTH': "Kap"}, {'IS_PUNCT': True, 'ORTH': '.'}, {IS_ROMAN: True},
                       {IS_DASHPUNCT: True, 'OP': '?'},
                       {'LIKE_NUM': False, 'IS_PUNCT': False, IS_SINGLELETTER: False, IS_INHALT: False, 'OP': '+'}]

    matcher.add('toc-chapter', None, toc_chapterTop1)
    matcher.add('toc-chapter', None, toc_chapterTop2)

    # **************************************************************

    part1 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
             {'LIKE_NUM': False, 'IS_PUNCT': False, 'OP': '+'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part2 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
             {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part3 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
             {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part4 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
             {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part5 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
             {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False}, {'ORTH': '.', 'OP': '+'},
             {'LIKE_NUM': True}]
    part6 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'ADJA', 'IS_PUNCT': True},
             {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part7 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'XY', 'IS_PUNCT': True},
             {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part8 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'VVFIN', 'IS_PUNCT': True},
             {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part9 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '$'}, {'ORTH': '.', 'OP': '+'},
             {'LIKE_NUM': True}]
    part10 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ':'}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part11 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '-'}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part12 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ';'}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part13 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'ff'},
              {'ORTH': '.'}, {'LIKE_NUM': False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part14 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ','}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part15 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'bzw'}, {'ORTH': '.'},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part16 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part17 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part18 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part19 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': ')'},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part20 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': '.', 'OP': '!'},
              {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part21 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'},
              {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part22 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part23 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part24 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    ################################################################################################
    part25 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'LENGTH': 1, 'OP': '!'},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part26 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part27 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part28 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part29 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part30 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'ADJA', 'IS_PUNCT': True},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part31 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'XY', 'IS_PUNCT': True},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part32 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'VVFIN', 'IS_PUNCT': True},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part33 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '$'},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part34 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ':'},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part35 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '-'},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part36 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ';'},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part37 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'ff'},
              {'ORTH': '.'}, {'LIKE_NUM': False}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part38 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ','},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part39 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'bzw'}, {'ORTH': '.'},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part40 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part41 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'LIKE_NUM': False}, {IS_tocStartPunct: True, 'POS': 'CARD'},
              {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part42 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {IS_tocStartPunct: True, 'POS': 'CARD'},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part43 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': ')'},
              {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part44 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': '.', 'OP': '!'},
              {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part45 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'},
              {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part46 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part47 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part48 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    #############################################################################################################################################################
    part49 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'LENGTH': 1, 'OP': '!'}, {rn_art: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part50 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part51 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part52 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part53 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False}, {rn_art: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part54 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'ADJA', 'IS_PUNCT': True},
              {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part55 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'XY', 'IS_PUNCT': True},
              {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part56 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'VVFIN', 'IS_PUNCT': True},
              {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part57 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '$'}, {rn_art: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part58 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ':'}, {rn_art: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part59 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '-'}, {rn_art: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part60 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ';'}, {rn_art: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part61 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'ff'},
              {'ORTH': '.'}, {'LIKE_NUM': False}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part62 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ','}, {rn_art: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part63 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'bzw'}, {'ORTH': '.'},
              {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part64 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part65 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'LIKE_NUM': False}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part66 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part67 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': ')'},
              {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part68 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': '.', 'OP': '!'},
              {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part69 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'},
              {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part70 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part71 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part72 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {rn_art: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    #######################################################################################################
    part73 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'LENGTH': 1, 'OP': '!'},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part74 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {'IS_PUNCT': True, stop: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part75 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {'IS_PUNCT': True, stop: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part76 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {'IS_PUNCT': True, stop: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part77 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
              {'IS_PUNCT': True, stop: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part78 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'ADJA', 'IS_PUNCT': True},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part79 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'XY', 'IS_PUNCT': True},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part80 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'VVFIN', 'IS_PUNCT': True},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part81 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '$'},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part82 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ':'},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part83 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '-'},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part84 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ';'},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part85 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'ff'},
              {'ORTH': '.'}, {'LIKE_NUM': False}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part86 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ','},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part87 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'bzw'}, {'ORTH': '.'},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part88 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part89 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part90 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {'IS_PUNCT': True, stop: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part91 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': ')'},
              {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part92 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': '.', 'OP': '!'},
              {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part93 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'},
              {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part94 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part95 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part96 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'},
              {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
              {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    ####################################################################################################################################################
    part97 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'LENGTH': 1, 'OP': '!'}, {'LIKE_NUM': True},
              {'ORTH': '.', 'OP': '+'}]
    part98 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part99 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
              {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
              {'LIKE_NUM': True}]
    part100 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part101 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part102 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'ADJA', 'IS_PUNCT': True},
               {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part103 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'XY', 'IS_PUNCT': True},
               {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part104 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'POS': 'VVFIN', 'IS_PUNCT': True},
               {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part105 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '$'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part106 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ':'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part107 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '-'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part108 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ';'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part109 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'ff'},
               {'ORTH': '.'}, {'LIKE_NUM': False}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part110 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': ','}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part111 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'bzw'}, {'ORTH': '.'},
               {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part112 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
               {'LIKE_NUM': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part113 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
               {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part114 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'},
               {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part115 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': ')'},
               {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part116 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': '.', 'OP': '!'},
               {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part117 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'},
               {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part118 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'},
               {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part119 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'},
               {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part120 = [{'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'},
               {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    #################################################################################################################################################

    part121 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'LENGTH': 1, 'OP': '!'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part122 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part123 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part124 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part125 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part126 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'ADJA', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part127 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'XY', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part128 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'VVFIN', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part129 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '$'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part130 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ':'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part131 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '-'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part132 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ';'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part133 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'LIKE_NUM': True}, {'ORTH': 'ff'}, {'ORTH': '.'}, {'LIKE_NUM': False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part134 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ','}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part135 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'bzw'}, {'ORTH': '.'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part136 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part137 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part138 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part139 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part140 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part141 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part142 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part143 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'},
               {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part144 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'},
               {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    ################################################################################################
    part145 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'LENGTH': 1, 'OP': '!'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part146 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part147 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part148 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part149 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part150 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'ADJA', 'IS_PUNCT': True}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part151 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'XY', 'IS_PUNCT': True}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part152 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'VVFIN', 'IS_PUNCT': True}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part153 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '$'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part154 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ':'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part155 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '-'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part156 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ';'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part157 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'LIKE_NUM': True}, {'ORTH': 'ff'}, {'ORTH': '.'}, {'LIKE_NUM': False},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part158 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ','}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part159 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'bzw'}, {'ORTH': '.'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part160 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part161 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part162 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part163 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part164 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part165 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part166 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part167 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'},
               {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part168 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'},
               {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    #############################################################################################################################################################
    part169 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'LENGTH': 1, 'OP': '!'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part170 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part171 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part172 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part173 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part174 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'ADJA', 'IS_PUNCT': True}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part175 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'XY', 'IS_PUNCT': True}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part176 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'VVFIN', 'IS_PUNCT': True}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part177 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '$'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part178 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ':'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part179 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '-'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part180 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ';'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part181 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'LIKE_NUM': True}, {'ORTH': 'ff'}, {'ORTH': '.'}, {'LIKE_NUM': False}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part182 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ','}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part183 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'bzw'}, {'ORTH': '.'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part184 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part185 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part186 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part187 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part188 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part189 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part190 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part191 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'},
               {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part192 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'},
               {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    #######################################################################################################
    part193 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'LENGTH': 1, 'OP': '!'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part194 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part195 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part196 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part197 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
               {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part198 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'ADJA', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part199 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'XY', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part200 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'VVFIN', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part201 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '$'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part202 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ':'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part203 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '-'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part204 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ';'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part205 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'LIKE_NUM': True}, {'ORTH': 'ff'}, {'ORTH': '.'}, {'LIKE_NUM': False}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part206 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ','}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part207 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'bzw'}, {'ORTH': '.'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part208 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part209 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part210 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
               {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part211 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part212 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part213 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part214 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'},
               {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part215 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'},
               {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part216 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'},
               {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    ####################################################################################################################################################
    part217 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'LENGTH': 1, 'OP': '!'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}]
    part218 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part219 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part220 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part221 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part222 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'ADJA', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part223 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'XY', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part224 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'POS': 'VVFIN', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part225 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '$'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part226 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ':'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part227 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '-'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part228 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ';'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part229 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'LIKE_NUM': True}, {'ORTH': 'ff'}, {'ORTH': '.'}, {'LIKE_NUM': False}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part230 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': ','}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part231 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'bzw'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part232 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part233 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part234 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part235 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part236 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part237 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part238 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part239 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'},
               {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part240 = [{'IS_LOWER': False, 'LIKE_NUM': False}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1}, {'ORTH': '.'},
               {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'},
               {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    ######################################################################################################################################################
    part241 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'LENGTH': 1, 'OP': '!'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part242 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part243 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part244 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part245 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part246 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'ADJA', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part247 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'XY', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part248 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'VVFIN', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part249 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '$'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part250 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ':'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part251 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '-'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part252 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ';'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part253 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'ff'}, {'ORTH': '.'}, {'LIKE_NUM': False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part254 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ','}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part255 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'bzw'}, {'ORTH': '.'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part256 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part257 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part258 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part259 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part260 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part261 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part262 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part263 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part264 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'},
               {'ORTH': '.'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    ################################################################################################
    part265 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'LENGTH': 1, 'OP': '!'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part266 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part267 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part268 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part269 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part270 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'ADJA', 'IS_PUNCT': True}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part271 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'XY', 'IS_PUNCT': True}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part272 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'VVFIN', 'IS_PUNCT': True}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part273 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '$'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part274 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ':'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part275 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '-'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part276 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ';'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part277 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'ff'}, {'ORTH': '.'}, {'LIKE_NUM': False},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part278 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ','}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part279 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'bzw'}, {'ORTH': '.'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part280 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True},
               {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part281 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part282 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part283 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part284 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part285 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part286 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'},
               {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part287 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'},
               {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part288 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'},
               {'ORTH': '.'}, {'ORTH': ')'}, {IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    #############################################################################################################################################################
    part289 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'LENGTH': 1, 'OP': '!'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part290 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part291 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part292 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part293 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
               {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part294 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'ADJA', 'IS_PUNCT': True}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part295 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'XY', 'IS_PUNCT': True}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part296 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'VVFIN', 'IS_PUNCT': True}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part297 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '$'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part298 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ':'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part299 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '-'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part300 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ';'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part301 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'ff'}, {'ORTH': '.'}, {'LIKE_NUM': False}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part302 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ','}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part303 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'bzw'}, {'ORTH': '.'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part304 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part305 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part306 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
               {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part307 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part308 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part309 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {rn_art: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part310 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'},
               {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part311 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part312 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'},
               {'ORTH': '.'}, {'ORTH': ')'}, {rn_art: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    #######################################################################################################
    part313 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'LENGTH': 1, 'OP': '!'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part314 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'},
               {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part315 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part316 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'},
               {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part317 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
               {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part318 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'ADJA', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part319 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'XY', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part320 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'VVFIN', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part321 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '$'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part322 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ':'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part323 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '-'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part324 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ';'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part325 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'ff'}, {'ORTH': '.'}, {'LIKE_NUM': False},
               {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part326 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ','}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part327 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'bzw'}, {'ORTH': '.'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part328 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part329 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False},
               {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part330 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
               {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part331 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part332 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part333 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
               {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part334 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'},
               {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part335 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part336 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'},
               {'ORTH': '.'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    ####################################################################################################################################################
    part337 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'LENGTH': 1, 'OP': '!'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}]
    part338 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'ADJA'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part339 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'NN'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part340 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'VVFIN'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part341 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
               {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part342 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'ADJA', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part343 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'XY', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part344 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'POS': 'VVFIN', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part345 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '$'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part346 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ':'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part347 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '-'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part348 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ';'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part349 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'ff'}, {'ORTH': '.'}, {'LIKE_NUM': False},
               {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part350 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': ','}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part351 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'bzw'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part352 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part353 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False},
               {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part354 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
               {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part355 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part356 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part357 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part358 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'},
               {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    part359 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True},
               {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
               {'LIKE_NUM': True}]
    part360 = [{'ORTH': 'Abs'}, {'IS_PUNCT': True}, {'LIKE_NUM': True}, {'IS_UPPER': True, IS_AL: True, 'LENGTH': 1},
               {'ORTH': '.'}, {'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'},
               {'ORTH': '.'}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]

    ##sample_list = []

    ##for pattern in range(1, 361):
    ##sample_list.append(locals()["part" + str(pattern)])
    #**Reason to comment: spacy not considering part rules, for some overlapping reason.
    ##for patterns in sample_list:
    ##    matcher.add('part', None, patterns)

    sample_list = []
    matcher.add('part', None, part1)
    matcher.add('part', None, part2)
    matcher.add('part', None, part3)
    matcher.add('part', None, part4)
    matcher.add('part', None, part5)
    matcher.add('part', None, part6)
    matcher.add('part', None, part7)
    matcher.add('part', None, part8)
    matcher.add('part', None, part9)
    matcher.add('part', None, part10)


    #####*****************subTocSubChapterExtractor********************###############################################

    subtocsubchapternumber = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}]
    SubChapter1 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]  ###additional
    SubChapter2 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'LIKE_NUM': False, IS_Nr: False}, {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter3 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                   {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False}, {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter4 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                   {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter5 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'POS': 'ADJA', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter6 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'POS': 'XY', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter7 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'POS': 'VVFIN', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter8 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '$'},
                   {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                   {'ORTH': '.'}]
    SubChapter9 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ':'},
                   {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                   {'ORTH': '.'}]
    SubChapter10 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ','},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter11 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '-'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter12 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter13 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'bzw'},
                    {'ORTH': '.'}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter14 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter15 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter16 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter17 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ';'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter18 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': ')'}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter19 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter20 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter21 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter22 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    #################################################################################
    SubChapter23 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]  ###additional
    SubChapter24 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, IS_Nr: False}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter25 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter26 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter27 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'ADJA', 'IS_PUNCT': True}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter28 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'XY', 'IS_PUNCT': True}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter29 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'VVFIN', 'IS_PUNCT': True}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter30 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '$'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter31 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ':'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter32 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ','},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter33 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '-'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter34 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter35 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'bzw'},
                    {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter36 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter37 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter38 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter39 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ';'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter40 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': ')'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter41 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter42 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter43 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter44 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    #################################################################
    SubChapter45 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]  ###additional
    SubChapter46 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, IS_Nr: False}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter47 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter48 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter49 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'ADJA', 'IS_PUNCT': True}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter50 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'XY', 'IS_PUNCT': True}, {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter51 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'VVFIN', 'IS_PUNCT': True}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter52 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '$'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter53 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ':'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter54 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ','},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter55 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '-'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter56 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'},
                    {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter57 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'bzw'},
                    {'ORTH': '.'}, {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter58 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter59 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter60 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter61 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ';'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter62 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': ')'}, {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter63 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter64 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter65 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter66 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    #########################################################################
    SubChapter67 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]  ###additional
    SubChapter68 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, IS_Nr: False}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter69 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False}, {'IS_PUNCT': True, stop: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter70 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter71 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'ADJA', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter72 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'XY', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter73 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'VVFIN', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter74 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '$'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter75 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ':'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter76 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ','},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter77 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '-'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter78 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'}, {'IS_PUNCT': True, stop: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter79 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'bzw'},
                    {'ORTH': '.'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter80 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter81 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'IS_PUNCT': True, stop: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter82 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter83 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ';'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter84 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter85 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter86 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter87 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter88 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    ##########################################################################
    SubChapter89 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'LIKE_NUM': True},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]  ###additional
    SubChapter90 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, IS_Nr: False}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter91 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter92 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False}, {'LIKE_NUM': True},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                    {'ORTH': '.'}]
    SubChapter93 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'ADJA', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter94 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'XY', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter95 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'VVFIN', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter96 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '$'},
                    {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter97 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ':'},
                    {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter98 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ','},
                    {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter99 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '-'},
                    {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter100 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                     {'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'}, {'LIKE_NUM': True},
                     {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                     {'ORTH': '.'}]
    SubChapter101 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'bzw'},
                     {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                     {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter102 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                     {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                     {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter103 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                     {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'LIKE_NUM': True},
                     {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                     {'ORTH': '.'}]
    SubChapter104 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                     {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {'LIKE_NUM': True},
                     {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False},
                     {'ORTH': '.'}]
    SubChapter105 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ';'},
                     {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                     {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter106 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                     {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                     {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter107 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                     {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                     {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter108 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                     {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                     {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter109 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                     {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                     {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                     {'IS_PUNCT': False}, {'ORTH': '.'}]
    SubChapter110 = [{IS_ROMAN: True, IS_XV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                     {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                     {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                     {'IS_PUNCT': False}, {'ORTH': '.'}]

    sample_list1 = []

    for pattern in range(1, 111):
        sample_list1.append(locals()["SubChapter" + str(pattern)])

    for patterns in sample_list1:
        matcher.add('SubChapter', None, patterns)

    ####(subchapter initiation)######
    SubChapter111 = [{'LIKE_NUM': False, IS_Nr: False}]
    SubChapter112 = [{'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False}]
    SubChapter113 = [{'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False}]
    SubChapter114 = [{'POS': 'ADJA', 'IS_PUNCT': True}]
    SubChapter115 = [{'POS': 'XY', 'IS_PUNCT': True}]
    SubChapter116 = [{'POS': 'VVFIN', 'IS_PUNCT': True}]
    SubChapter117 = [{'ORTH': '$'}]
    SubChapter118 = [{'ORTH': ':'}]
    SubChapter119 = [{'ORTH': ','}]
    SubChapter120 = [{'ORTH': '-'}]
    SubChapter121 = [{'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'}]
    SubChapter122 = [{'ORTH': 'bzw'}, {'ORTH': '.'}]
    SubChapter123 = [{'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}]
    SubChapter124 = [{'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}]
    SubChapter125 = [{'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}]
    SubChapter126 = [{'ORTH': ';'}]
    SubChapter127 = [{'ORTH': '('}, {'ORTH': ')'}]
    SubChapter128 = [{'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}]
    SubChapter129 = [{'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}]
    SubChapter130 = [{'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'},
                     {'ORTH': ')'}]
    SubChapter131 = [{'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'},
                     {'ORTH': ')'}]
    ####################################################################################################################################

    subtocsubchapternumber_2 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}]
    subChapter1 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False},
                   {'ORTH': '.'}]  ###additional
    subChapter2 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'LIKE_NUM': False, IS_Nr: False}, {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter3 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                   {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False}, {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter4 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                   {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter5 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'POS': 'ADJA', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter6 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'POS': 'XY', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter7 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                   {'POS': 'VVFIN', 'IS_PUNCT': True}, {'ORTH': '.', 'OP': '*'},
                   {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter8 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '$'},
                   {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                   {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter9 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ':'},
                   {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                   {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter10 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ','},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter11 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '-'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter12 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter13 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'bzw'},
                    {'ORTH': '.'}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter14 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter15 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter16 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter17 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ';'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter18 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': ')'}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter19 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter20 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter21 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter22 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    ################################################################################
    subChapter23 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False},
                    {'ORTH': '.'}]  ###additional
    subChapter24 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, IS_Nr: False}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter25 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter26 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter27 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'ADJA', 'IS_PUNCT': True}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter28 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'XY', 'IS_PUNCT': True}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter29 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'VVFIN', 'IS_PUNCT': True}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter30 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '$'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter31 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ':'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter32 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ','},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter33 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '-'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter34 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter35 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'bzw'},
                    {'ORTH': '.'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter36 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter37 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter38 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter39 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ';'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter40 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': ')'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter41 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter42 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter43 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter44 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    #################################################################
    subChapter45 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False},
                    {'ORTH': '.'}]  ###additional
    subChapter46 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, IS_Nr: False}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter47 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter48 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter49 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'ADJA', 'IS_PUNCT': True}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter50 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'XY', 'IS_PUNCT': True}, {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter51 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'VVFIN', 'IS_PUNCT': True}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter52 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '$'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter53 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ':'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter54 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ','},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter55 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '-'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter56 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'},
                    {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter57 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'bzw'},
                    {'ORTH': '.'}, {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter58 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter59 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter60 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter61 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ';'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter62 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': ')'}, {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter63 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter64 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'LIKE_NUM': False, rn_art: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter65 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter66 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                    {'LIKE_NUM': False, rn_art: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    #########################################################################
    subChapter67 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False},
                    {'ORTH': '.'}]  ###additional
    subChapter68 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, IS_Nr: False}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter69 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False}, {'IS_PUNCT': True, stop: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter70 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter71 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'ADJA', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter72 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'XY', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter73 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'VVFIN', 'IS_PUNCT': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter74 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '$'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter75 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ':'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter76 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ','},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter77 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '-'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter78 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'}, {'IS_PUNCT': True, stop: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter79 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'bzw'},
                    {'ORTH': '.'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter80 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter81 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'IS_PUNCT': True, stop: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter82 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter83 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ';'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter84 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': ')'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter85 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter86 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter87 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter88 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                    {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                    {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    ##########################################################################
    subChapter89 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'LIKE_NUM': True},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]  ###additional
    subChapter90 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'LIKE_NUM': False, IS_Nr: False}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter91 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                    {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter92 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False}, {'LIKE_NUM': True},
                    {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter93 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'ADJA', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter94 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'XY', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter95 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                    {'POS': 'VVFIN', 'IS_PUNCT': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                    {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter96 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '$'},
                    {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter97 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ':'},
                    {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter98 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ','},
                    {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter99 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '-'},
                    {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                    {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter100 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'},
                     {'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'}, {'LIKE_NUM': True},
                     {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                     {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter101 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'bzw'},
                     {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                     {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False},
                     {'ORTH': '.'}]
    subChapter102 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                     {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                     {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False},
                     {'ORTH': '.'}]
    subChapter103 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                     {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'LIKE_NUM': True},
                     {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                     {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter104 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': 'Nr'},
                     {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {'LIKE_NUM': True},
                     {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                     {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter105 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': ';'},
                     {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                     {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter106 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                     {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                     {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False},
                     {'ORTH': '.'}]
    subChapter107 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                     {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                     {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False},
                     {'ORTH': '.'}]
    subChapter108 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                     {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'},
                     {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'}, {'ÍS_J': False, 'IS_PUNCT': False},
                     {'ORTH': '.'}]
    subChapter109 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                     {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'},
                     {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                     {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]
    subChapter110 = [{IS_ROMAN: True, IS_XIV: True, 'OP': '+'}, {'IS_PUNCT': True, 'ORTH': '.'}, {'ORTH': '('},
                     {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                     {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '*'}, {'LIKE_NUM': True, 'POS': 'ADJA', 'OP': '!'},
                     {'ÍS_J': False, 'IS_PUNCT': False}, {'ORTH': '.'}]

    sample_list = []

    for pattern in range(1, 111):
        sample_list.append(locals()["subChapter" + str(pattern)])

    for patterns in sample_list:
        matcher.add('subChapter', None, patterns)

    ####(subchapter initiation)######
    subChapter111 = [{'LIKE_NUM': False, IS_Nr: False}]
    subChapter112 = [{'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': False, IS_Nr: False}]
    subChapter113 = [{'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False}]
    subChapter114 = [{'POS': 'ADJA', 'IS_PUNCT': True}]
    subChapter115 = [{'POS': 'XY', 'IS_PUNCT': True}]
    subChapter116 = [{'POS': 'VVFIN', 'IS_PUNCT': True}]
    subChapter117 = [{'ORTH': '$'}]
    subChapter118 = [{'ORTH': ':'}]
    subChapter119 = [{'ORTH': ','}]
    subChapter120 = [{'ORTH': '-'}]
    subChapter121 = [{'LIKE_NUM': False, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '!'}]
    subChapter122 = [{'ORTH': 'bzw'}, {'ORTH': '.'}]
    subChapter123 = [{'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}]
    subChapter124 = [{'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'LIKE_NUM': False}]
    subChapter125 = [{'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}]
    subChapter126 = [{'ORTH': ';'}]
    subChapter127 = [{'ORTH': '('}, {'ORTH': ')'}]
    subChapter128 = [{'ORTH': '('}, {'ORTH': '.', 'OP': '!'}, {'ORTH': ')'}]
    subChapter129 = [{'ORTH': '('}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'}]
    subChapter130 = [{'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '!'},
                     {'ORTH': ')'}]
    subChapter131 = [{'ORTH': '('}, {'ORTH': 'Nr'}, {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'},
                     {'ORTH': ')'}]
    ####################################################################################################################################
    #################**************************************SubTocSubSUbChapterExtractor*****************############################

    subeditTocSubSubChapterNumber = [{'LIKE_NUM': True, 'POS': 'ADJ', 'LENGTH': 1}, {'ORTH': '.'},
                                     {is_au: False, 'LIKE_NUM': False, 'IS_PUNCT': False, 'OP': '+'},
                                     {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]

    subeditTocSubSubChapterNumber1 = [{'LIKE_NUM': True, 'POS': 'ADJ', 'LENGTH': 2}, {'ORTH': '.'},
                                      {'LIKE_NUM': False, 'IS_PUNCT': False, is_au: False, 'OP': '+'},
                                      {'ORTH': '.', 'OP': '+'},
                                      {'LIKE_NUM': True}]

    subeditTocSubSubChapterNumber2 = [{'LIKE_NUM': True, 'POS': 'ADJ', 'LENGTH': 3}, {'ORTH': '.'},
                                      {'LIKE_NUM': False, 'IS_PUNCT': False, is_au: False, 'OP': '+'},
                                      {'ORTH': '.', 'OP': '+'},
                                      {'LIKE_NUM': True}]

    subeditTocSubSubChapterNumber3 = [{'LIKE_NUM': True, }, {'ORTH': '.'},
                                      {'LIKE_NUM': False, 'IS_PUNCT': False, is_au: False, 'OP': '+'},
                                      {'IS_PUNCT': True, IS_tocStartPunct: True},
                                      {'LIKE_NUM': False, 'IS_PUNCT': False, is_au: False, 'OP': '+'},
                                      {'IS_PUNCT': True, IS_tocStartPunct: True},
                                      {'LIKE_NUM': False, 'IS_PUNCT': False, 'OP': '+'}, {'ORTH': '.', 'OP': '+'},
                                      {'LIKE_NUM': True}]

    subeditTocSubSubChapterNumber4 = [{'LIKE_NUM': True, }, {'ORTH': '.'},
                                      {'LIKE_NUM': False, 'IS_PUNCT': False, is_au: False, 'OP': '+'},
                                      {is_au: False},
                                      {is_au: False},
                                      {'LIKE_NUM': False, 'IS_PUNCT': False, is_au: False, 'OP': '+'},
                                      {'ORTH': '.', 'OP': '+'},
                                      {'LIKE_NUM': True}]

    matcher.add('subTocSubSubChapter', None, subeditTocSubSubChapterNumber)
    matcher.add('subTocSubSubChapter', None, subeditTocSubSubChapterNumber1)
    matcher.add('subTocSubSubChapter', None, subeditTocSubSubChapterNumber2)
    matcher.add('subTocSubSubChapter', None, subeditTocSubSubChapterNumber3)
    matcher.add('subTocSubSubChapter', None, subeditTocSubSubChapterNumber4)
    subTocSubSubChapterNumber1 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                  {'LIKE_NUM': False, IS_spec_list: False},
                                  {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                  {'LIKE_NUM': True}]
    subTocSubSubChapterNumber2 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2},
                                  {'LIKE_NUM': False, IS_spec_list: False},
                                  {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                  {'LIKE_NUM': True}]
    subTocSubSubChapterNumber3 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'LIKE_NUM': True},
                                  {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                  {'LIKE_NUM': True}]
    subTocSubSubChapterNumber4 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2},
                                  {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                                  {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                  {'LIKE_NUM': True}]
    subTocSubSubChapterNumber5 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'ADJA', 'IS_PUNCT': True},
                                  {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                  {'LIKE_NUM': True}]
    subTocSubSubChapterNumber6 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'XY', 'IS_PUNCT': True},
                                  {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                  {'LIKE_NUM': True}]
    subTocSubSubChapterNumber7 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'VVFIN', 'IS_PUNCT': True},
                                  {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                  {'LIKE_NUM': True}]
    subTocSubSubChapterNumber8 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '$'},
                                  {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                  {'LIKE_NUM': True}]
    subTocSubSubChapterNumber9 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': ':'},
                                  {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                  {'LIKE_NUM': True}]
    subTocSubSubChapterNumber10 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'LIKE_NUM': False, 'POS': 'CARD'},
                                   {'ORTH': '.', 'OP': '!'}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber11 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'bzw'}, {'ORTH': '.'},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber12 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber13 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'LIKE_NUM': False},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber14 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber15 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '-'},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber16 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': ';'},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber17 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': ')'},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber18 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber19 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('},
                                   {stop: False, 'OP': '*'}, {'ORTH': ')'},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber20 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {stop: False, 'OP': '*'}, {'ORTH': ')'},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber21 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'u'},
                                   {'ORTH': '.'}, {'ORTH': ')'},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber22 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD'}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    #####################################
    subTocSubSubChapterNumber23 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': False, IS_spec_list: False}, {'LIKE_NUM': False, IS_Rn_Nr_Art: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber24 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2},
                                   {'LIKE_NUM': False, IS_spec_list: False}, {'LIKE_NUM': False, IS_Rn_Nr_Art: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber25 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'LIKE_NUM': True},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber26 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber27 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'ADJA', 'IS_PUNCT': True},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber28 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'XY', 'IS_PUNCT': True},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber29 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'VVFIN', 'IS_PUNCT': True},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber30 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '$'},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber31 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': ':'},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber32 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'LIKE_NUM': False, 'POS': 'CARD'},
                                   {'ORTH': '.', 'OP': '!'}, {'LIKE_NUM': False, IS_Rn_Nr_Art: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber33 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'bzw'}, {'ORTH': '.'},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber34 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'LIKE_NUM': False, IS_Rn_Nr_Art: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber35 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'LIKE_NUM': False, IS_Rn_Nr_Art: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber36 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber37 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '-'},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber38 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': ';'},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber39 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': ')'},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber40 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber41 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('},
                                   {stop: False, 'OP': '*'}, {'ORTH': ')'}, {'LIKE_NUM': False, IS_Rn_Nr_Art: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber42 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {stop: False, 'OP': '*'}, {'ORTH': ')'},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber43 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'u'},
                                   {'ORTH': '.'}, {'ORTH': ')'}, {'LIKE_NUM': False, IS_Rn_Nr_Art: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber44 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                                   {'LIKE_NUM': False, IS_Rn_Nr_Art: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    ##################################
    subTocSubSubChapterNumber45 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': False, IS_spec_list: False}, {'IS_PUNCT': True, stop: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber46 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2},
                                   {'LIKE_NUM': False, IS_spec_list: False}, {'IS_PUNCT': True, stop: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber47 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'LIKE_NUM': True},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber48 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber49 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'ADJA', 'IS_PUNCT': True},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber50 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'XY', 'IS_PUNCT': True},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber51 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'VVFIN', 'IS_PUNCT': True},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber52 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '$'},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber53 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': ':'},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber54 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'LIKE_NUM': False, 'POS': 'CARD'},
                                   {'ORTH': '.', 'OP': '!'}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber55 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'bzw'}, {'ORTH': '.'},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber56 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber57 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'IS_PUNCT': True, stop: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber58 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber59 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '-'},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber60 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': ';'},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber61 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': ')'},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber62 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber63 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('},
                                   {stop: False, 'OP': '*'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber64 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {stop: False, 'OP': '*'}, {'ORTH': ')'},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber65 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'u'},
                                   {'ORTH': '.'}, {'ORTH': ')'}, {'IS_PUNCT': True, stop: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber66 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                                   {'IS_PUNCT': True, stop: False}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    ###############################
    subTocSubSubChapterNumber67 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': False, IS_spec_list: False}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber68 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2},
                                   {'LIKE_NUM': False, IS_spec_list: False}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber69 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'LIKE_NUM': True},
                                   {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber70 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                                   {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber71 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'ADJA', 'IS_PUNCT': True},
                                   {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber72 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'XY', 'IS_PUNCT': True},
                                   {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber73 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'VVFIN', 'IS_PUNCT': True},
                                   {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber74 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '$'}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber75 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': ':'}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber76 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'LIKE_NUM': False, 'POS': 'CARD'},
                                   {'ORTH': '.', 'OP': '!'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber77 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'bzw'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber78 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber79 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber80 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber81 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '-'}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber82 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': ';'}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber83 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': ')'},
                                   {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber84 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber85 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('},
                                   {stop: False, 'OP': '*'}, {'ORTH': ')'}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber86 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {stop: False, 'OP': '*'}, {'ORTH': ')'},
                                   {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber87 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'u'},
                                   {'ORTH': '.'}, {'ORTH': ')'}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber88 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                   {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                                   {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    ###############################################
    subTocSubSubChapterNumber89 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                   {'LIKE_NUM': False, IS_spec_list: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber90 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2},
                                   {'LIKE_NUM': False, IS_spec_list: False}, {'ORTH': '.', 'OP': '+'},
                                   {'LIKE_NUM': True}]
    subTocSubSubChapterNumber91 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'LIKE_NUM': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber92 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2},
                                   {'IS_PUNCT': True, IS_tocStartPunct: True, 'POS': 'CARD', IS_BRACK: False},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber93 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'ADJA', 'IS_PUNCT': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber94 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'XY', 'IS_PUNCT': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber95 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'POS': 'VVFIN', 'IS_PUNCT': True},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber96 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '$'},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber97 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': ':'},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber98 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'LIKE_NUM': False, 'POS': 'CARD'},
                                   {'ORTH': '.', 'OP': '!'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber99 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'bzw'}, {'ORTH': '.'},
                                   {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber100 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                    {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber101 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                    {'LIKE_NUM': True}, {'LIKE_NUM': False}, {'ORTH': '.', 'OP': '+'},
                                    {'LIKE_NUM': True}]
    subTocSubSubChapterNumber102 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': 'Nr'}, {'ORTH': '.'},
                                    {'LIKE_NUM': True}, {'ORTH': ','}, {'LIKE_NUM': True}, {'ORTH': '.', 'OP': '+'},
                                    {'LIKE_NUM': True}]
    subTocSubSubChapterNumber103 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '-'},
                                    {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber104 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': ';'},
                                    {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber105 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': ')'},
                                    {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber106 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'},
                                    {'LIKE_NUM': True}]
    subTocSubSubChapterNumber107 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('},
                                    {stop: False, 'OP': '*'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'},
                                    {'LIKE_NUM': True}]
    subTocSubSubChapterNumber108 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                    {'ORTH': '.'}, {'LIKE_NUM': True}, {stop: False, 'OP': '*'}, {'ORTH': ')'},
                                    {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber109 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'u'},
                                    {'ORTH': '.'}, {'ORTH': ')'}, {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]
    subTocSubSubChapterNumber110 = [{'LIKE_NUM': True, 'POS': 'ADJA', 'LENGTH': 2}, {'ORTH': '('}, {'ORTH': 'Nr'},
                                    {'ORTH': '.'}, {'LIKE_NUM': True}, {'ORTH': 'u'}, {'ORTH': '.'}, {'ORTH': ')'},
                                    {'ORTH': '.', 'OP': '+'}, {'LIKE_NUM': True}]

    matcher.add('subTocSubSubChapterNumber', None, subeditTocSubSubChapterNumber)
    matcher.add('subTocSubSubChapterNumber', None, subeditTocSubSubChapterNumber1)
    matcher.add('subTocSubSubChapterNumber', None, subeditTocSubSubChapterNumber2)
    matcher.add('subTocSubSubChapterNumber', None, subeditTocSubSubChapterNumber3)
    matcher.add('subTocSubSubChapterNumber', None, subeditTocSubSubChapterNumber4)
    sample_list = []

    for pattern in range(1, 111):
        sample_list.append(locals()["subTocSubSubChapterNumber" + str(pattern)])

    for patterns in sample_list:
        matcher.add('subTocSubSubChapterNumber', None, patterns)
    #######################################################################################
    IS_OMITSIGN = nlp.vocab.add_flag(lambda text: text in ['(', ')', '\'', '/', ';', 'Rn', 'nach', 'gemäß'])

    ref_Extractor = [{'ORTH': "§", 'OP': '+'}, {IS_OMITSIGN: True, 'IS_TITLE': False, 'POS': 'VAFIN', 'OP': '!'},
                     {IS_OMITSIGN: False, 'IS_UPPER': False, 'OP': '?'},
                     {IS_OMITSIGN: False, 'IS_UPPER': False, 'OP': '?'},
                     {IS_OMITSIGN: False, 'IS_UPPER': False, 'OP': '?'},
                     {IS_OMITSIGN: False, 'IS_UPPER': False, 'OP': '?'},
                     {IS_OMITSIGN: False, 'IS_UPPER': False, 'OP': '?'}, {'IS_UPPER': True}]
    ref_Extractor2 = [{'ORTH': "Art"}, {'ORTH': "."}, {IS_OMITSIGN: True, 'POS': 'VAFIN', 'OP': '!'},
                      {'IS_UPPER': True, 'OP': '+'}]
    ref_Extractor3 = [{'ORTH': "Art"}, {'ORTH': "."}, {IS_OMITSIGN: True, 'POS': 'VAFIN', 'OP': '!'},
                      {'IS_UPPER': False, 'IS_LOWER': False, 'OP': '+'}]
    ref_Extractor4 = [{'LIKE_NUM': True, 'SHAPE': 'dddd'}, {'ORTH': "/"}, {'IS_UPPER': True}]
    ref_Extractor5 = [{'LIKE_NUM': True, 'SHAPE': 'dddd'}, {'POS': 'NUM'}, {'ORTH': "/"}, {'IS_UPPER': True}]
    ref_Extractor6 = [{'POS': 'NUM'}, {'ORTH': "/"}, {'POS': 'NUM'}, {'ORTH': "/"}, {'IS_UPPER': True}]

    matcher.add('gesetz1', None, ref_Extractor)
    matcher.add('gesetz2', None, ref_Extractor2)
    matcher.add('gesetz2', None, ref_Extractor3)
    matcher.add('gesetz3', None, ref_Extractor4)
    matcher.add('gesetz4', None, ref_Extractor5)
    matcher.add(' ', None, ref_Extractor5)

    matches = matcher(doc2)

    endRuleMatch = time.time()
    hours, rem = divmod(endRuleMatch - startRuleMatch, 3600)
    minutes, seconds = divmod(rem, 60)
    print("Time taken Spacy's Rule based Matcher")
    print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    with open('TimeTrack.txt', 'a') as f:
        print("", file=f)
        print("Time taken Spacy's Rule based Matcher", file=f)
        print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds), file=f)

    # *************************DBPedia Tagging and Rule Data-structure Creation*************************************

    startDBpediaTag = time.time()

    for match_id, start, end in matches:
        LocalRule = []
        string_id = nlp.vocab.strings[match_id]  # get string representation
        span = doc2[start:end]  # the matched span

        try:
            annotations = spotlight.annotate('http://api.dbpedia-spotlight.org/de/annotate', span.text, confidence=0.9,
                                             support=10)
            # print("Dbpedia: ", annotations)
        except:
            annotations = ""
            # print ("Exception")

        LocalRule.append(span.text)
        LocalRule.append(str(start) + "-" + str(end))

        if string_id in SubRule:
            LocalRule.append("Reference")
            LocalRule.append(string_id)
        else:
            LocalRule.append(string_id)
            LocalRule.append(" ")

        LocalRule.append(annotations)
        if LocalRule in RuleList:
            pass
        else:
            RuleList.append(LocalRule)

        print("")
        print(string_id, start, end, span.text)

    endDBpediaTag = time.time()
    hours, rem = divmod(endDBpediaTag - startDBpediaTag, 3600)
    minutes, seconds = divmod(rem, 60)
    print("Time taken DBPedia tagger")
    print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))

    with open('TimeTrack.txt', 'a') as f:
        print("", file=f)
        print("Time taken DBPedia tagger", file=f)
        print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds), file=f)

    print("The final Rules are: ")
    print(RuleList)

#****************Count Variable for each rule****************************
    subTocSubSubChapterNumber = 0
    Reference = 0
    tocchapter = 0
    subChapter = 0
    part = 0


# ****************Redundancy Elimination****************************
    temp_RuleList = RuleList
    listo_array = np.array(temp_RuleList)
    list1 = listo_array[:, 1]
    list_unique, list_index = np.unique(list1, return_index=True)
    list_index.sort()
    RuleList1 = []
    for i in range(0, list_index.shape[0]):
        RuleList1.append(listo_array[list_index[i]])

    FinalResult = [list(j) for j in RuleList1]

    print("Final Table of Contents List is :")
    print(FinalResult)

    for i in FinalResult:

        # Counting the number matched phares to each rule
        if i[2] == 'subTocSubSubChapter':
            subTocSubSubChapterNumber += 1
        elif i[2] == 'Reference':
            Reference += 1
        elif i[2] == 'toc-chapter':
            tocchapter += 1
        elif i[2] == 'subChapter':
            subChapter += 1
        elif i[2] == 'part':
            part += 1
        # Printing the Rules into the output file
        with open(output, 'a') as f:
            print("", file=f)
            print("Rule", i, file=f)

    print("toc-chapter: ", tocchapter)
    print("subChapter: ", subChapter)
    print("subTocSubSubChapterNumber: ", subTocSubSubChapterNumber)
    print("part: ", part)
    print("Reference: ", Reference)
    print("No of Phrase mached with the rules: ", len(FinalResult))

    endIttr = time.time()
    hours, rem = divmod(endIttr - startRead, 3600)
    minutes, seconds = divmod(rem, 60)
    print("Total time taken")
    print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    with open('TimeTrack.txt', 'a') as f:
        print("", file=f)
        print("Time taken for this Itteration : ", file=f)
        print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds), file=f)

    RuleList = []
    FinalResult = []
    counter += 1

ticks1 = time.time()

hours, rem = divmod(ticks1 - ticks, 3600)
minutes, seconds = divmod(rem, 60)
print("*****************************************")
print("Total time taken")
print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
with open('TimeTrack.txt', 'a') as f:
    print("", file=f)
    print("Total Time taken : ", file=f)
    print("{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds), file=f)



